/**
 * Created by Administrator on 2017/4/17 0017.
 */


File file = new File('E:\\Groovy\\Class\\listener1\\ant_project\\build.xml')

file.start {
    println 'start'
}